public class Player  {
	
	private String name;
	private int age;
	
	Player(String name,int age) {
		this.name = name;
		this.age=age;
	}
	
	public void setName(String name){
		this.name=name;
	}
	public void setAge(int age){
		this.age=age;
	}
	
	public String getName(){
		return this.name;
	}
	public int getAge(){
		return this.age;
	}
	
	public String talents(){
		new Object(){
			
			void showTalents(){
				System.out.println("A good player");
			}
		};
		System.out.println("A good player");
		return "A good Player";
	
	}
	
	public int playerHelth(){
		class MedicleReports{
			private int sugger;
			public MedicleReports(int sugger,int height,int weight) {
				this.sugger = sugger;
			}
			 MedicleReports() {
			}

			public void setSugger(int sugger){
				this.sugger = sugger;
			}
			
			public int getSugger(){
				return this.sugger;
			}	
		}
		MedicleReports mr = new MedicleReports();
		mr.setSugger(87);
		return mr.getSugger();
	}
	class PastRecords{
		private int numOfMatches;
		
		PastRecords(int numOfMatches) {
			this.numOfMatches = numOfMatches;
			
		}
		
		public int getNumOfMatches(){
			return this.numOfMatches;
		}	
	}
	
}
