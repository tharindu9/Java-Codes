import java.util.List;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Team team = new Team(2);
		Player player = new Player("tharindu ariyarathna",24);
		String playerName =player.getName() ;//player.name;
		System.out.println("Player name is "+ playerName + "Player is "+ player.getAge());
		List<Player> players = team.getPlayers();
		for(Player p : players){
			System.out.println("Members of team : " + p.getName());
			System.out.println(player.getName()+ " paticipated to "
					+player.new PastRecords(2).getNumOfMatches()
					+ "matches and sugger " + player.playerHelth() + "and his skills :"
					+ player.talents());
		}
		
		 
		System.out.println(player.getName()+ " paticipated to "
				+player.new PastRecords(2).getNumOfMatches()
				+ "matches and sugger " + player.playerHelth() + "and his skills :"
				+ player.talents());
		
	
		
	}

}
