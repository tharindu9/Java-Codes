import java.util.*;

public class Team {
	List<Player> players =new ArrayList <Player>();
	
//	{
//		players = new ArrayList <Player>();
//	}
	Team(int n){
		for(int i=0;i<n;i++){
			players.add(new Player("tharindu",24));
		}
	}
	
	public List<Player> getPlayers(){
		return this.players;
	}

}
