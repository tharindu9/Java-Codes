import java.util.Scanner;

import jdk.nashorn.internal.ir.ContinueNode;

public class Main {

	public static void main(String[] args) {
		System.out.println("Enter the password ");
		Scanner sc = new Scanner(System.in);
		int pass = sc.nextInt();
		new Main().getMoney(pass);

	}

	Creadits creadits = new Creadits();
	Scanner scanner = new Scanner(System.in);

	public void getMoney(int password) {

		if (creadits.accountValidation(password)) {
			System.out.println("Enter the ammount ");
			int mny = scanner.nextInt();
			if (creadits.checkBalance(mny)) {
				System.out.println("You have withdraw " + mny);
			} else {
				System.out
						.println("Maximum ammount you can withdraw is 200000");
			}
		}
		else{
			System.out.println("Wrong Password");
			System.exit(0);
		}
	}

}
