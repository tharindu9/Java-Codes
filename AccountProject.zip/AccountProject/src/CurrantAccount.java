
public class CurrantAccount extends Account {

}
