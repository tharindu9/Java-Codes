
public class CreditAccount extends Account{
	
	int accountNumber = 1234;
	public boolean accountValidation(int password){
		if(password==accountNumber){
			return true;
		}
		else{
			return false;
		}
		
	}

}
