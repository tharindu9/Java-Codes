
public class Visa extends CreditAccount {
	
	static int currantMoney = 200000;
	public boolean checkBalance(int money){
		if(currantMoney >= money){
			return true;	
		}
		else{
			return false;
		}
		
	}

}
