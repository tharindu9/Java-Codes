
public class Debit extends Visa {

}
