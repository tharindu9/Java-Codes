
public class Creadits extends Visa{

	public int withDraw(int money){
		
		return money;
	}
}
