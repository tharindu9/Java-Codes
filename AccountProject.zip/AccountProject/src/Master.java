
public class Master extends CreditAccount{

}
